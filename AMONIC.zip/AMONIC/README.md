# AirlinesSession1

Готовый проект для **AMONIC Airlines** на **WPF / C# / .NET Framework 4.8** с объединением требований **Session 1** и **Session 2**.

## Что внутри

- `database/AmonicAirlines_Full.sql` — основной SQL-скрипт, который сразу:
  - создаёт БД `AmonicAirlinesDB`
  - создаёт SQL login `amonic_app`
  - задаёт пароль `AmonicApp_2025!`
  - загружает структуру и данные из Session 2
  - импортирует пользователей Session 1
  - сохраняет пароли в открытом виде, как в `UserData.csv`
  - создаёт таблицу `UserSessions` для логина / логаута / неправильного выхода
  - создаёт представления и процедуры для приложения
- `src/AirlinesSession1.sln` — solution для Visual Studio
- `src/AirlinesSession1/` — исходники WPF-приложения
- `database/AmonicAirlines_RemoveMd5_Patch.sql` — патч для уже существующей `AmonicAirlinesDB`, если не хочешь пересоздавать БД
- `src/AirlinesSession1/Samples/` — тестовые CSV для импорта изменений расписания

## Реализовано

### Session 1
- авторизация по `Email`
- хранение и проверка пароля в открытом виде, без MD5
- задержка на **10 секунд** после 3 неудачных попыток входа
- сообщение о заблокированном пользователе
- админская форма пользователей
- добавление пользователя
- смена роли
- блокировка / разблокировка логина
- пользовательская страница с историей активности
- окно **No logout detected** с выбором `Software Crash` / `System Crash`

### Session 2
- форма **Manage Flight Schedules**
- фильтры по аэропортам, дате и номеру рейса
- сортировка
- отмена / подтверждение рейса
- редактирование даты, времени и цены эконом-класса
- импорт изменений из CSV с результатами:
  - успешные изменения
  - дубликаты
  - строки с пропущенными полями / ошибочными данными

## Подготовка БД

1. Открой `database/AmonicAirlines_Full.sql` в SQL Server Management Studio.
2. Выполни скрипт целиком от имени пользователя с правами на создание БД и логинов.
3. После выполнения появится БД `AmonicAirlinesDB` и SQL login:
   - login: `amonic_app`
   - password: `AmonicApp_2025!`

## Подключение приложения

По умолчанию в `App.config` указан сервер:

- `localhost\SQLEXPRESS`

Если у тебя другой экземпляр SQL Server, измени только `Data Source` в `src/AirlinesSession1/App.config`.

Приложение подключается **только через SQL Server Authentication**.

## Тестовые аккаунты

Администратор:
- `j.doe@amonic.com` / `123`

Пользователи:
- `k.omar@amonic.com` / `4258`
- `h.saeed@amonic.com` / `2020`
- `a.hobart@amonic.com` / `6996`
- `k.anderson@amonic.com` / `4570`
- `h.wyrick@amonic.com` / `1199`
- `marie.horn@amonic.com` / `55555`
- `m.osteen@amonic.com` / `9800` *(неактивный пользователь, вход запрещён)*

## Запуск в Visual Studio

1. Открой `src/AirlinesSession1.sln`
2. Убедись, что установлен workload **.NET desktop development**
3. Выставь проект `AirlinesSession1` как Startup Project
4. Запусти приложение

## Структура проекта

- `Infrastructure` — подключение к БД и контекст текущей сессии
- `Models` — модели для экранов
- `Services` — логика авторизации, пользователей и расписаний
- `Utilities` — вспомогательные функции форматирования времени
- `Views` — WPF-окна

## Git

В корне уже инициализирован локальный git-репозиторий и добавлены несколько коммитов по этапам разработки.
