/*
    Patch script for an existing AmonicAirlinesDB database.
    Removes MD5 password usage by replacing stored hashes with the original plain-text passwords
    from UserData.csv and keeps the same database name and login.
*/
USE [AmonicAirlinesDB]
GO

UPDATE dbo.Users SET [Password] = N'123'   WHERE Email = N'j.doe@amonic.com';
UPDATE dbo.Users SET [Password] = N'4258'  WHERE Email = N'k.omar@amonic.com';
UPDATE dbo.Users SET [Password] = N'2020'  WHERE Email = N'h.saeed@amonic.com';
UPDATE dbo.Users SET [Password] = N'6996'  WHERE Email = N'a.hobart@amonic.com';
UPDATE dbo.Users SET [Password] = N'4570'  WHERE Email = N'k.anderson@amonic.com';
UPDATE dbo.Users SET [Password] = N'1199'  WHERE Email = N'h.wyrick@amonic.com';
UPDATE dbo.Users SET [Password] = N'55555' WHERE Email = N'marie.horn@amonic.com';
UPDATE dbo.Users SET [Password] = N'9800'  WHERE Email = N'm.osteen@amonic.com';
GO

/* Optional: add/update a short note so it is obvious that passwords are plain-text in this version */
PRINT N'Passwords in dbo.Users are now stored in plain text for the WPF demo version.';
GO
