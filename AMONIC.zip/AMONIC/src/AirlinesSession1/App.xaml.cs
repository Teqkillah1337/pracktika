using System.Windows;

namespace AirlinesSession1
{
    public partial class App : Application
    {
    }
}
