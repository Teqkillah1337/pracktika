using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AirlinesSession1")]
[assembly: AssemblyDescription("AMONIC Airlines - Session 1 + Session 2")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("OpenAI")]
[assembly: AssemblyProduct("AirlinesSession1")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("f4c0d8da-9d55-4d07-a24a-6d6d3f3d91ae")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
