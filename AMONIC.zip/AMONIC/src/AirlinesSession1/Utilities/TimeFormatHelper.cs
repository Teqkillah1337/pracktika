using System;

namespace AirlinesSession1.Utilities
{
    public static class TimeFormatHelper
    {
        public static string SecondsToClock(long seconds)
        {
            if (seconds < 0)
            {
                seconds = 0;
            }

            var time = TimeSpan.FromSeconds(seconds);
            return string.Format("{0:00}:{1:00}:{2:00}", (int)time.TotalHours, time.Minutes, time.Seconds);
        }
    }
}
