using System.Configuration;
using System.Data.SqlClient;

namespace AirlinesSession1.Infrastructure
{
    public static class Db
    {
        public static SqlConnection OpenConnection()
        {
            var settings = ConfigurationManager.ConnectionStrings["AmonicAirlinesDb"];
            if (settings == null || string.IsNullOrWhiteSpace(settings.ConnectionString))
            {
                throw new ConfigurationErrorsException("Connection string 'AmonicAirlinesDb' was not found in App.config.");
            }

            var connection = new SqlConnection(settings.ConnectionString);
            connection.Open();
            return connection;
        }
    }
}
