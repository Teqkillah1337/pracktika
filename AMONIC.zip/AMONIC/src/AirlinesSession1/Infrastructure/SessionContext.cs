using AirlinesSession1.Models;

namespace AirlinesSession1.Infrastructure
{
    public static class SessionContext
    {
        public static CurrentUser CurrentUser { get; set; }

        public static int CurrentSessionId { get; set; }

        public static void Clear()
        {
            CurrentUser = null;
            CurrentSessionId = 0;
        }
    }
}
