using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using AirlinesSession1.Infrastructure;
using AirlinesSession1.Models;

namespace AirlinesSession1.Services
{
    public class UserService
    {
        public List<OfficeItem> GetOffices(bool includeAll = false)
        {
            var result = new List<OfficeItem>();
            if (includeAll)
            {
                result.Add(new OfficeItem { Id = null, Title = "All offices" });
            }

            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("SELECT ID, Title FROM dbo.Offices ORDER BY Title;", connection))
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    result.Add(new OfficeItem
                    {
                        Id = Convert.ToInt32(reader["ID"]),
                        Title = Convert.ToString(reader["Title"])
                    });
                }
            }

            return result;
        }

        public List<AdminUserItem> GetUsers(int? officeId)
        {
            var result = new List<AdminUserItem>();
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand(@"
SELECT ID, FirstName, LastName, Age, RoleTitle, RoleID, Email, OfficeID, OfficeTitle, Active
FROM dbo.vw_AdminUsers
WHERE (@OfficeID IS NULL OR OfficeID = @OfficeID)
ORDER BY FirstName, LastName;", connection))
            {
                command.Parameters.AddWithValue("@OfficeID", (object)officeId ?? DBNull.Value);
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new AdminUserItem
                        {
                            Id = Convert.ToInt32(reader["ID"]),
                            FirstName = reader["FirstName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["FirstName"]),
                            LastName = Convert.ToString(reader["LastName"]),
                            Age = reader["Age"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Age"]),
                            RoleTitle = Convert.ToString(reader["RoleTitle"]),
                            RoleId = Convert.ToInt32(reader["RoleID"]),
                            Email = Convert.ToString(reader["Email"]),
                            OfficeId = reader["OfficeID"] == DBNull.Value ? (int?)null : Convert.ToInt32(reader["OfficeID"]),
                            OfficeTitle = reader["OfficeTitle"] == DBNull.Value ? string.Empty : Convert.ToString(reader["OfficeTitle"]),
                            Active = Convert.ToBoolean(reader["Active"])
                        });
                    }
                }
            }

            return result;
        }

        public void ToggleUserActive(int userId, bool active)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("UPDATE dbo.Users SET Active = @Active WHERE ID = @ID;", connection))
            {
                command.Parameters.AddWithValue("@ID", userId);
                command.Parameters.AddWithValue("@Active", active);
                command.ExecuteNonQuery();
            }
        }

        public void ChangeUserRole(int userId, int roleId)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("UPDATE dbo.Users SET RoleID = @RoleID WHERE ID = @ID;", connection))
            {
                command.Parameters.AddWithValue("@ID", userId);
                command.Parameters.AddWithValue("@RoleID", roleId);
                command.ExecuteNonQuery();
            }
        }

        public void AddUser(AddUserRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException("request");
            }

            using (var connection = Db.OpenConnection())
            {
                using (var checkCommand = new SqlCommand("SELECT COUNT(1) FROM dbo.Users WHERE Email = @Email;", connection))
                {
                    checkCommand.Parameters.AddWithValue("@Email", request.Email.Trim());
                    var count = Convert.ToInt32(checkCommand.ExecuteScalar());
                    if (count > 0)
                    {
                        throw new InvalidOperationException("Пользователь с таким e-mail уже существует.");
                    }
                }

                using (var command = new SqlCommand(@"
DECLARE @NewID INT = ISNULL((SELECT MAX(ID) FROM dbo.Users), 0) + 1;
INSERT INTO dbo.Users(ID, RoleID, Email, Password, FirstName, LastName, OfficeID, Birthdate, Active)
VALUES(@NewID, 2, @Email, @Password, @FirstName, @LastName, @OfficeID, @Birthdate, 1);", connection))
                {
                    command.Parameters.AddWithValue("@Email", request.Email.Trim());
                    command.Parameters.AddWithValue("@Password", request.Password.Trim());
                    command.Parameters.AddWithValue("@FirstName", request.FirstName.Trim());
                    command.Parameters.AddWithValue("@LastName", request.LastName.Trim());
                    command.Parameters.AddWithValue("@OfficeID", request.OfficeId);
                    command.Parameters.AddWithValue("@Birthdate", request.Birthdate.Date);
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<UserActivityItem> GetActivities(int userId)
        {
            var result = new List<UserActivityItem>();
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand(@"
SELECT ActivityDate, LoginTime, LogoutTime, TimeSpentText, CrashReason, HasCrash
FROM dbo.vw_UserActivity
WHERE UserID = @UserID
  AND IsOpenSession = 0
ORDER BY LoginTime DESC;", connection))
            {
                command.Parameters.AddWithValue("@UserID", userId);
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var loginTime = Convert.ToDateTime(reader["LoginTime"]);
                        var logoutTime = reader["LogoutTime"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(reader["LogoutTime"]);
                        var timeSpentText = reader["TimeSpentText"] == DBNull.Value ? "**" : Convert.ToString(reader["TimeSpentText"]);
                        var crashReason = reader["CrashReason"] == DBNull.Value ? string.Empty : Convert.ToString(reader["CrashReason"]);
                        var hasCrash = Convert.ToBoolean(reader["HasCrash"]);

                        result.Add(new UserActivityItem
                        {
                            DateText = loginTime.ToString("dd/MM/yyyy"),
                            LoginTimeText = loginTime.ToString("HH:mm"),
                            LogoutTimeText = logoutTime.HasValue ? logoutTime.Value.ToString("HH:mm") : "**",
                            TimeSpentText = string.IsNullOrWhiteSpace(timeSpentText) ? "**" : timeSpentText,
                            CrashReason = crashReason,
                            HasCrash = hasCrash
                        });
                    }
                }
            }

            return result;
        }

        public UserDashboardSummary GetDashboardSummary(int userId)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand(@"
SELECT
    ISNULL(SUM(CASE WHEN LoginTime >= DATEADD(DAY, -30, SYSDATETIME()) AND LogoutTime IS NOT NULL THEN DATEDIFF(SECOND, LoginTime, LogoutTime) ELSE 0 END), 0) AS TotalSeconds,
    ISNULL(SUM(CASE WHEN CrashType IS NOT NULL OR CrashReason IS NOT NULL THEN 1 ELSE 0 END), 0) AS CrashCount
FROM dbo.UserSessions
WHERE UserID = @UserID;", connection))
            {
                command.Parameters.AddWithValue("@UserID", userId);
                using (var reader = command.ExecuteReader())
                {
                    reader.Read();
                    var seconds = Convert.ToInt64(reader["TotalSeconds"]);
                    return new UserDashboardSummary
                    {
                        TimeSpentLast30DaysText = SecondsToClock(seconds),
                        CrashCount = Convert.ToInt32(reader["CrashCount"])
                    };
                }
            }
        }

        private static string SecondsToClock(long seconds)
        {
            if (seconds < 0)
            {
                seconds = 0;
            }

            var time = TimeSpan.FromSeconds(seconds);
            return string.Format("{0:00}:{1:00}:{2:00}", (int)time.TotalHours, time.Minutes, time.Seconds);
        }
    }
}
