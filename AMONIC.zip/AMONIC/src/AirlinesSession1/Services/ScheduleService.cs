using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using AirlinesSession1.Infrastructure;
using AirlinesSession1.Models;

namespace AirlinesSession1.Services
{
    public class ScheduleService
    {
        public List<AirportItem> GetAirports()
        {
            var result = new List<AirportItem>();
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("SELECT ID, IATACode, Name FROM dbo.Airports ORDER BY IATACode;", connection))
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    result.Add(new AirportItem
                    {
                        Id = Convert.ToInt32(reader["ID"]),
                        Code = Convert.ToString(reader["IATACode"]),
                        Name = Convert.ToString(reader["Name"])
                    });
                }
            }

            return result;
        }

        public List<ScheduleItem> GetSchedules(ScheduleFilter filter)
        {
            var result = new List<ScheduleItem>();
            filter = filter ?? new ScheduleFilter();

            var sql = new StringBuilder();
            sql.Append(@"
SELECT ID, DepartureDate, DepartureTime, DepartureAirportCode, ArrivalAirportCode,
       FlightNumber, AircraftName, AircraftID, EconomyPrice, BusinessPrice, FirstClassPrice, Confirmed
FROM dbo.vw_ScheduleManagement
WHERE 1 = 1");

            if (!string.IsNullOrWhiteSpace(filter.FromCode))
            {
                sql.Append(" AND DepartureAirportCode = @FromCode");
            }

            if (!string.IsNullOrWhiteSpace(filter.ToCode))
            {
                sql.Append(" AND ArrivalAirportCode = @ToCode");
            }

            if (filter.DepartureDate.HasValue)
            {
                sql.Append(" AND DepartureDate = @DepartureDate");
            }

            if (!string.IsNullOrWhiteSpace(filter.FlightNumber))
            {
                sql.Append(" AND FlightNumber LIKE @FlightNumber");
            }

            var orderBy = "DepartureDate, DepartureTime";
            if (string.Equals(filter.SortBy, "Economy price", StringComparison.OrdinalIgnoreCase))
            {
                orderBy = "EconomyPrice, DepartureDate, DepartureTime";
            }
            else if (string.Equals(filter.SortBy, "Confirmed / Not Confirmed", StringComparison.OrdinalIgnoreCase))
            {
                orderBy = "Confirmed, DepartureDate, DepartureTime";
            }

            sql.Append(" ORDER BY " + orderBy + ";");

            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand(sql.ToString(), connection))
            {
                if (!string.IsNullOrWhiteSpace(filter.FromCode))
                {
                    command.Parameters.AddWithValue("@FromCode", filter.FromCode);
                }

                if (!string.IsNullOrWhiteSpace(filter.ToCode))
                {
                    command.Parameters.AddWithValue("@ToCode", filter.ToCode);
                }

                if (filter.DepartureDate.HasValue)
                {
                    command.Parameters.AddWithValue("@DepartureDate", filter.DepartureDate.Value.Date);
                }

                if (!string.IsNullOrWhiteSpace(filter.FlightNumber))
                {
                    command.Parameters.AddWithValue("@FlightNumber", "%" + filter.FlightNumber.Trim() + "%");
                }

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var date = Convert.ToDateTime(reader["DepartureDate"]);
                        var time = (TimeSpan)reader["DepartureTime"];
                        var economyPrice = Convert.ToDecimal(reader["EconomyPrice"]);
                        var businessPrice = Convert.ToDecimal(reader["BusinessPrice"]);
                        var firstClassPrice = Convert.ToDecimal(reader["FirstClassPrice"]);

                        result.Add(new ScheduleItem
                        {
                            Id = Convert.ToInt32(reader["ID"]),
                            DepartureDate = date,
                            DepartureTime = time,
                            DepartureDateText = date.ToString("dd/MM/yyyy"),
                            DepartureTimeText = time.ToString(@"hh\:mm"),
                            DepartureAirportCode = Convert.ToString(reader["DepartureAirportCode"]),
                            ArrivalAirportCode = Convert.ToString(reader["ArrivalAirportCode"]),
                            FlightNumber = Convert.ToString(reader["FlightNumber"]),
                            AircraftName = Convert.ToString(reader["AircraftName"]),
                            AircraftId = Convert.ToInt32(reader["AircraftID"]),
                            EconomyPrice = economyPrice,
                            BusinessPrice = businessPrice,
                            FirstClassPrice = firstClassPrice,
                            EconomyPriceText = string.Format("${0:F0}", economyPrice),
                            BusinessPriceText = string.Format("${0:F0}", businessPrice),
                            FirstClassPriceText = string.Format("${0:F0}", firstClassPrice),
                            Confirmed = Convert.ToBoolean(reader["Confirmed"])
                        });
                    }
                }
            }

            return result;
        }

        public void ToggleConfirmed(int scheduleId, bool confirmed)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("UPDATE dbo.Schedules SET Confirmed = @Confirmed WHERE ID = @ID;", connection))
            {
                command.Parameters.AddWithValue("@ID", scheduleId);
                command.Parameters.AddWithValue("@Confirmed", confirmed);
                command.ExecuteNonQuery();
            }
        }

        public void UpdateSchedule(int scheduleId, DateTime date, TimeSpan time, decimal economyPrice)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("UPDATE dbo.Schedules SET [Date] = @Date, [Time] = @Time, EconomyPrice = @Price WHERE ID = @ID;", connection))
            {
                command.Parameters.AddWithValue("@ID", scheduleId);
                command.Parameters.AddWithValue("@Date", date.Date);
                command.Parameters.Add("@Time", SqlDbType.Time).Value = time;
                command.Parameters.AddWithValue("@Price", economyPrice);
                command.ExecuteNonQuery();
            }
        }

        public ImportResult ImportChanges(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
            {
                throw new FileNotFoundException("Файл не найден.", filePath);
            }

            var result = new ImportResult();
            var lines = File.ReadAllLines(filePath);
            var seenKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            using (var connection = Db.OpenConnection())
            using (var transaction = connection.BeginTransaction())
            {
                try
                {
                    var airportMap = LoadAirportMap(connection, transaction);
                    foreach (var rawLine in lines)
                    {
                        var line = (rawLine ?? string.Empty).Trim();
                        if (string.IsNullOrWhiteSpace(line))
                        {
                            continue;
                        }

                        var parts = line.Split(',');
                        if (parts.Length != 9 || parts.Any(part => string.IsNullOrWhiteSpace(part)))
                        {
                            result.RecordsWithMissingFieldsDiscarded++;
                            continue;
                        }

                        var action = parts[0].Trim().ToUpperInvariant();
                        var dateText = parts[1].Trim();
                        var timeText = parts[2].Trim();
                        var flightNumber = parts[3].Trim();
                        var fromCode = parts[4].Trim().ToUpperInvariant();
                        var toCode = parts[5].Trim().ToUpperInvariant();
                        var aircraftText = parts[6].Trim();
                        var priceText = parts[7].Trim();
                        var confirmedText = parts[8].Trim().ToUpperInvariant();

                        if (action != "ADD" && action != "EDIT")
                        {
                            result.RecordsWithMissingFieldsDiscarded++;
                            continue;
                        }

                        DateTime departureDate;
                        TimeSpan departureTime;
                        int aircraftId;
                        decimal economyPrice;
                        if (!DateTime.TryParseExact(dateText, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out departureDate) ||
                            !TryParseTime(timeText, out departureTime) ||
                            !int.TryParse(aircraftText, NumberStyles.Integer, CultureInfo.InvariantCulture, out aircraftId) ||
                            !decimal.TryParse(priceText, NumberStyles.Number, CultureInfo.InvariantCulture, out economyPrice))
                        {
                            result.RecordsWithMissingFieldsDiscarded++;
                            continue;
                        }

                        if (!airportMap.ContainsKey(fromCode) || !airportMap.ContainsKey(toCode))
                        {
                            result.RecordsWithMissingFieldsDiscarded++;
                            continue;
                        }

                        var key = flightNumber + "|" + departureDate.ToString("yyyyMMdd");
                        if (!seenKeys.Add(key))
                        {
                            result.DuplicateRecordsDiscarded++;
                            continue;
                        }

                        var routeId = FindRouteId(connection, transaction, airportMap[fromCode], airportMap[toCode]);
                        if (routeId <= 0)
                        {
                            result.RecordsWithMissingFieldsDiscarded++;
                            continue;
                        }

                        var confirmed = confirmedText == "OK";
                        if (confirmedText != "OK" && confirmedText != "CANCELED" && confirmedText != "CANCELLED")
                        {
                            result.RecordsWithMissingFieldsDiscarded++;
                            continue;
                        }

                        var existingScheduleId = FindScheduleId(connection, transaction, flightNumber, departureDate);
                        if (action == "ADD")
                        {
                            if (existingScheduleId > 0)
                            {
                                result.DuplicateRecordsDiscarded++;
                                continue;
                            }

                            using (var insert = new SqlCommand(@"
INSERT INTO dbo.Schedules([Date], [Time], AircraftID, RouteID, EconomyPrice, Confirmed, FlightNumber)
VALUES(@Date, @Time, @AircraftID, @RouteID, @EconomyPrice, @Confirmed, @FlightNumber);", connection, transaction))
                            {
                                insert.Parameters.AddWithValue("@Date", departureDate.Date);
                                insert.Parameters.Add("@Time", SqlDbType.Time).Value = departureTime;
                                insert.Parameters.AddWithValue("@AircraftID", aircraftId);
                                insert.Parameters.AddWithValue("@RouteID", routeId);
                                insert.Parameters.AddWithValue("@EconomyPrice", economyPrice);
                                insert.Parameters.AddWithValue("@Confirmed", confirmed);
                                insert.Parameters.AddWithValue("@FlightNumber", flightNumber);
                                insert.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            if (existingScheduleId <= 0)
                            {
                                result.RecordsWithMissingFieldsDiscarded++;
                                continue;
                            }

                            using (var update = new SqlCommand(@"
UPDATE dbo.Schedules
SET [Time] = @Time,
    AircraftID = @AircraftID,
    RouteID = @RouteID,
    EconomyPrice = @EconomyPrice,
    Confirmed = @Confirmed
WHERE ID = @ID;", connection, transaction))
                            {
                                update.Parameters.AddWithValue("@ID", existingScheduleId);
                                update.Parameters.Add("@Time", SqlDbType.Time).Value = departureTime;
                                update.Parameters.AddWithValue("@AircraftID", aircraftId);
                                update.Parameters.AddWithValue("@RouteID", routeId);
                                update.Parameters.AddWithValue("@EconomyPrice", economyPrice);
                                update.Parameters.AddWithValue("@Confirmed", confirmed);
                                update.ExecuteNonQuery();
                            }
                        }

                        result.SuccessfulChangesApplied++;
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }

            return result;
        }

        private static Dictionary<string, int> LoadAirportMap(SqlConnection connection, SqlTransaction transaction)
        {
            var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            using (var command = new SqlCommand("SELECT IATACode, ID FROM dbo.Airports;", connection, transaction))
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    result[Convert.ToString(reader["IATACode"])] = Convert.ToInt32(reader["ID"]);
                }
            }

            return result;
        }

        private static int FindRouteId(SqlConnection connection, SqlTransaction transaction, int departureAirportId, int arrivalAirportId)
        {
            using (var command = new SqlCommand(@"
SELECT TOP 1 ID
FROM dbo.Routes
WHERE DepartureAirportID = @DepartureAirportID
  AND ArrivalAirportID = @ArrivalAirportID
ORDER BY ID;", connection, transaction))
            {
                command.Parameters.AddWithValue("@DepartureAirportID", departureAirportId);
                command.Parameters.AddWithValue("@ArrivalAirportID", arrivalAirportId);
                var value = command.ExecuteScalar();
                return value == null || value == DBNull.Value ? 0 : Convert.ToInt32(value);
            }
        }

        private static int FindScheduleId(SqlConnection connection, SqlTransaction transaction, string flightNumber, DateTime departureDate)
        {
            using (var command = new SqlCommand(@"
SELECT TOP 1 ID
FROM dbo.Schedules
WHERE FlightNumber = @FlightNumber
  AND [Date] = @DepartureDate;", connection, transaction))
            {
                command.Parameters.AddWithValue("@FlightNumber", flightNumber);
                command.Parameters.AddWithValue("@DepartureDate", departureDate.Date);
                var value = command.ExecuteScalar();
                return value == null || value == DBNull.Value ? 0 : Convert.ToInt32(value);
            }
        }

        private static bool TryParseTime(string value, out TimeSpan time)
        {
            return TimeSpan.TryParseExact(value, new[] { @"hh\:mm", @"h\:mm", @"hh\:mm\:ss" }, CultureInfo.InvariantCulture, out time);
        }
    }
}
