using System;
using System.Data;
using System.Data.SqlClient;
using AirlinesSession1.Infrastructure;
using AirlinesSession1.Models;

namespace AirlinesSession1.Services
{
    public class AuthService
    {
        public AuthResult Authenticate(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                return new AuthResult { Success = false, Message = "Введите e-mail и пароль." };
            }

            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand(@"
SELECT u.ID,
       u.RoleID,
       r.Title AS RoleTitle,
       u.Email,
       u.FirstName,
       u.LastName,
       CAST(ISNULL(u.Active, 0) AS bit) AS Active,
       u.[Password]
FROM dbo.Users u
INNER JOIN dbo.Roles r ON r.ID = u.RoleID
WHERE u.Email = @Email;", connection))
            {
                command.Parameters.AddWithValue("@Email", email.Trim());

                using (var reader = command.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        return new AuthResult { Success = false, Message = "Неверный e-mail или пароль." };
                    }

                    var isActive = reader.GetBoolean(reader.GetOrdinal("Active"));
                    if (!isActive)
                    {
                        return new AuthResult
                        {
                            Success = false,
                            IsBlocked = true,
                            Message = "Вход невозможен: пользователь заблокирован администратором."
                        };
                    }

                    var storedPassword = reader["Password"] == DBNull.Value ? string.Empty : Convert.ToString(reader["Password"]);
                    var incomingPassword = password.Trim();
                    if (!string.Equals(storedPassword, incomingPassword, StringComparison.Ordinal))
                    {
                        return new AuthResult { Success = false, Message = "Неверный e-mail или пароль." };
                    }

                    return new AuthResult
                    {
                        Success = true,
                        User = new CurrentUser
                        {
                            Id = Convert.ToInt32(reader["ID"]),
                            RoleId = Convert.ToInt32(reader["RoleID"]),
                            RoleTitle = Convert.ToString(reader["RoleTitle"]),
                            Email = Convert.ToString(reader["Email"]),
                            FirstName = reader["FirstName"] == DBNull.Value ? string.Empty : Convert.ToString(reader["FirstName"]),
                            LastName = Convert.ToString(reader["LastName"]),
                            Active = isActive
                        }
                    };
                }
            }
        }

        public CrashSessionInfo GetPendingCrashSession(int userId)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand(@"
SELECT TOP 1 ID, LoginTime
FROM dbo.UserSessions
WHERE UserID = @UserID
  AND LogoutTime IS NULL
  AND CrashType IS NULL
  AND CrashReason IS NULL
ORDER BY LoginTime DESC;", connection))
            {
                command.Parameters.AddWithValue("@UserID", userId);
                using (var reader = command.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        return null;
                    }

                    return new CrashSessionInfo
                    {
                        SessionId = Convert.ToInt32(reader["ID"]),
                        LoginTime = Convert.ToDateTime(reader["LoginTime"])
                    };
                }
            }
        }

        public void MarkSessionCrash(int sessionId, string crashType, string crashReason)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("dbo.usp_MarkSessionCrash", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@SessionID", sessionId);
                command.Parameters.AddWithValue("@CrashType", (object)(crashType ?? string.Empty));
                command.Parameters.AddWithValue("@CrashReason", (object)(crashReason ?? string.Empty));
                command.ExecuteNonQuery();
            }
        }

        public int StartSession(int userId)
        {
            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("dbo.usp_StartUserSession", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserID", userId);
                var value = command.ExecuteScalar();
                return Convert.ToInt32(value);
            }
        }

        public void CloseSession(int sessionId)
        {
            if (sessionId <= 0)
            {
                return;
            }

            using (var connection = Db.OpenConnection())
            using (var command = new SqlCommand("dbo.usp_CloseUserSession", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@SessionID", sessionId);
                command.ExecuteNonQuery();
            }
        }
    }
}
