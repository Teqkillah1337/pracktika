using System;

namespace AirlinesSession1.Models
{
    public class AddUserRequest
    {
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int OfficeId { get; set; }
        public DateTime Birthdate { get; set; }
        public string Password { get; set; }
    }
}
