namespace AirlinesSession1.Models
{
    public class ImportResult
    {
        public int SuccessfulChangesApplied { get; set; }
        public int DuplicateRecordsDiscarded { get; set; }
        public int RecordsWithMissingFieldsDiscarded { get; set; }
    }
}
