namespace AirlinesSession1.Models
{
    public class AdminUserItem
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string RoleTitle { get; set; }
        public int RoleId { get; set; }
        public string Email { get; set; }
        public int? OfficeId { get; set; }
        public string OfficeTitle { get; set; }
        public bool Active { get; set; }
    }
}
