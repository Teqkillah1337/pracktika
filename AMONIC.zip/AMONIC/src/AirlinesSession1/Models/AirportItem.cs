namespace AirlinesSession1.Models
{
    public class AirportItem
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public override string ToString() { return string.Format("{0} - {1}", Code, Name); }
    }
}
