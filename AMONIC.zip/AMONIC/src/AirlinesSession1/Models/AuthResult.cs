namespace AirlinesSession1.Models
{
    public class AuthResult
    {
        public bool Success { get; set; }
        public bool IsBlocked { get; set; }
        public string Message { get; set; }
        public CurrentUser User { get; set; }
    }
}
