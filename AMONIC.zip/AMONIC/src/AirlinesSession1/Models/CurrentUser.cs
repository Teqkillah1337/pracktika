namespace AirlinesSession1.Models
{
    public class CurrentUser
    {
        public int Id { get; set; }
        public int RoleId { get; set; }
        public string RoleTitle { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool Active { get; set; }
        public bool IsAdmin { get { return RoleId == 1; } }
        public string FullName { get { return string.Format("{0} {1}", FirstName ?? string.Empty, LastName ?? string.Empty).Trim(); } }
    }
}
