using System;

namespace AirlinesSession1.Models
{
    public class ScheduleItem
    {
        public int Id { get; set; }
        public DateTime DepartureDate { get; set; }
        public TimeSpan DepartureTime { get; set; }
        public string DepartureDateText { get; set; }
        public string DepartureTimeText { get; set; }
        public string DepartureAirportCode { get; set; }
        public string ArrivalAirportCode { get; set; }
        public string FlightNumber { get; set; }
        public string AircraftName { get; set; }
        public int AircraftId { get; set; }
        public decimal EconomyPrice { get; set; }
        public decimal BusinessPrice { get; set; }
        public decimal FirstClassPrice { get; set; }
        public string EconomyPriceText { get; set; }
        public string BusinessPriceText { get; set; }
        public string FirstClassPriceText { get; set; }
        public bool Confirmed { get; set; }
    }
}
