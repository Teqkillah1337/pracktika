namespace AirlinesSession1.Models
{
    public class UserDashboardSummary
    {
        public string TimeSpentLast30DaysText { get; set; }
        public int CrashCount { get; set; }
    }
}
