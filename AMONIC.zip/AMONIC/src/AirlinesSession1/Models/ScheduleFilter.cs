using System;

namespace AirlinesSession1.Models
{
    public class ScheduleFilter
    {
        public string FromCode { get; set; }
        public string ToCode { get; set; }
        public DateTime? DepartureDate { get; set; }
        public string FlightNumber { get; set; }
        public string SortBy { get; set; }
    }
}
