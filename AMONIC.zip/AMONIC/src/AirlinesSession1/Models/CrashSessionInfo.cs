using System;

namespace AirlinesSession1.Models
{
    public class CrashSessionInfo
    {
        public int SessionId { get; set; }
        public DateTime LoginTime { get; set; }
    }
}
