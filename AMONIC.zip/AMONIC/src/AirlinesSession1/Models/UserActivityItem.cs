namespace AirlinesSession1.Models
{
    public class UserActivityItem
    {
        public string DateText { get; set; }
        public string LoginTimeText { get; set; }
        public string LogoutTimeText { get; set; }
        public string TimeSpentText { get; set; }
        public string CrashReason { get; set; }
        public bool HasCrash { get; set; }
    }
}
