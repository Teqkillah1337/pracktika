using System;
using System.Windows;
using AirlinesSession1.Infrastructure;
using AirlinesSession1.Services;

namespace AirlinesSession1.Views
{
    public partial class UserWindow : Window
    {
        private readonly UserService _userService = new UserService();
        private readonly AuthService _authService = new AuthService();

        public UserWindow()
        {
            InitializeComponent();
            Loaded += UserWindow_Loaded;
        }

        private void UserWindow_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            var user = SessionContext.CurrentUser;
            if (user == null)
            {
                return;
            }

            txtGreeting.Text = string.Format("Hi {0}, Welcome to AMONIC Airlines.", user.FullName);
            var summary = _userService.GetDashboardSummary(user.Id);
            txtTimeSpent.Text = summary.TimeSpentLast30DaysText;
            txtCrashCount.Text = summary.CrashCount.ToString();
            dgActivities.ItemsSource = _userService.GetActivities(user.Id);
        }

        private void ManageSchedules_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ManageFlightSchedulesWindow { Owner = this };
            dialog.ShowDialog();
            RefreshData();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _authService.CloseSession(SessionContext.CurrentSessionId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Logout", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            SessionContext.Clear();
            var login = new LoginWindow();
            Application.Current.MainWindow = login;
            login.Show();
            Close();
        }
    }
}
