using System;
using System.Windows;
using AirlinesSession1.Models;

namespace AirlinesSession1.Views
{
    public partial class CrashReasonWindow : Window
    {
        public string SelectedCrashType { get; private set; }
        public string CrashReason { get; private set; }

        public CrashReasonWindow(CrashSessionInfo sessionInfo)
        {
            InitializeComponent();
            rbSoftware.IsChecked = true;
            txtHeader.Text = string.Format("No logout detected for your last login on {0}", sessionInfo.LoginTime.ToString("dd/MM/yyyy 'at' HH:mm"));
        }

        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (rbSoftware.IsChecked != true && rbSystem.IsChecked != true)
            {
                MessageBox.Show(this, "Выберите тип сбоя.", "No logout detected", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            SelectedCrashType = rbSoftware.IsChecked == true ? "Software Crash" : "System Crash";
            CrashReason = string.IsNullOrWhiteSpace(txtReason.Text) ? SelectedCrashType : txtReason.Text.Trim();
            DialogResult = true;
        }
    }
}
