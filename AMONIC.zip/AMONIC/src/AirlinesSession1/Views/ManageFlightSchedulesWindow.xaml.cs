using System;
using System.Collections.Generic;
using System.Windows;
using AirlinesSession1.Models;
using AirlinesSession1.Services;

namespace AirlinesSession1.Views
{
    public partial class ManageFlightSchedulesWindow : Window
    {
        private readonly ScheduleService _scheduleService = new ScheduleService();

        public ManageFlightSchedulesWindow()
        {
            InitializeComponent();
            Loaded += ManageFlightSchedulesWindow_Loaded;
        }

        private void ManageFlightSchedulesWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadLookups();
            LoadSchedules();
        }

        private void LoadLookups()
        {
            var airports = _scheduleService.GetAirports();
            var withPlaceholder = new List<AirportItem> { new AirportItem { Id = 0, Code = "[ Airport list ]", Name = string.Empty } };
            withPlaceholder.AddRange(airports);

            cmbFrom.ItemsSource = withPlaceholder;
            cmbTo.ItemsSource = new List<AirportItem>(withPlaceholder);
            cmbFrom.SelectedIndex = 0;
            cmbTo.SelectedIndex = 0;

            cmbSortBy.ItemsSource = new[] { "Date-Time", "Economy price", "Confirmed / Not Confirmed" };
            cmbSortBy.SelectedIndex = 0;
        }

        private void LoadSchedules()
        {
            var from = cmbFrom.SelectedItem as AirportItem;
            var to = cmbTo.SelectedItem as AirportItem;
            if (from != null && to != null && from.Id > 0 && to.Id > 0 && from.Id == to.Id)
            {
                MessageBox.Show(this, "Аэропорт отправления и прибытия не могут совпадать.", "Schedules", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var filter = new ScheduleFilter
            {
                FromCode = from != null && from.Id > 0 ? from.Code : null,
                ToCode = to != null && to.Id > 0 ? to.Code : null,
                DepartureDate = dpOutbound.SelectedDate,
                FlightNumber = txtFlightNumber.Text,
                SortBy = Convert.ToString(cmbSortBy.SelectedItem)
            };
            dgSchedules.ItemsSource = _scheduleService.GetSchedules(filter);
            UpdateButtons();
        }

        private ScheduleItem GetSelectedSchedule()
        {
            return dgSchedules.SelectedItem as ScheduleItem;
        }

        private void UpdateButtons()
        {
            var schedule = GetSelectedSchedule();
            var enabled = schedule != null;
            btnEditFlight.IsEnabled = enabled;
            btnToggleConfirmed.IsEnabled = enabled;
            btnToggleConfirmed.Content = enabled ? (schedule.Confirmed ? "Cancel Flight" : "Confirm Flight") : "Cancel Flight";
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadSchedules();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Schedules", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DgSchedules_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            UpdateButtons();
        }

        private void ToggleConfirmed_Click(object sender, RoutedEventArgs e)
        {
            var schedule = GetSelectedSchedule();
            if (schedule == null)
            {
                return;
            }

            try
            {
                _scheduleService.ToggleConfirmed(schedule.Id, !schedule.Confirmed);
                LoadSchedules();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Schedules", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void EditFlight_Click(object sender, RoutedEventArgs e)
        {
            var schedule = GetSelectedSchedule();
            if (schedule == null)
            {
                return;
            }

            var dialog = new EditFlightWindow(schedule) { Owner = this };
            if (dialog.ShowDialog() == true)
            {
                LoadSchedules();
            }
        }

        private void ImportChanges_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ImportChangesWindow { Owner = this };
            dialog.ShowDialog();
            LoadSchedules();
        }
    }
}
