using System;
using System.Windows;
using AirlinesSession1.Infrastructure;
using AirlinesSession1.Models;
using AirlinesSession1.Services;

namespace AirlinesSession1.Views
{
    public partial class AdminWindow : Window
    {
        private readonly UserService _userService = new UserService();
        private readonly AuthService _authService = new AuthService();

        public AdminWindow()
        {
            InitializeComponent();
            Loaded += AdminWindow_Loaded;
        }

        private void AdminWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadOffices();
            LoadUsers();
        }

        private void LoadOffices()
        {
            cmbOffices.ItemsSource = _userService.GetOffices(true);
            cmbOffices.SelectedIndex = 0;
        }

        private void LoadUsers()
        {
            var selectedOffice = cmbOffices.SelectedItem as OfficeItem;
            dgUsers.ItemsSource = _userService.GetUsers(selectedOffice == null ? null : selectedOffice.Id);
            UpdateSelectedUserUi();
        }

        private AdminUserItem GetSelectedUser()
        {
            return dgUsers.SelectedItem as AdminUserItem;
        }

        private void UpdateSelectedUserUi()
        {
            var user = GetSelectedUser();
            var hasSelection = user != null;
            btnChangeRole.IsEnabled = hasSelection;
            btnToggleActive.IsEnabled = hasSelection;
            btnToggleActive.Content = hasSelection ? (user.Active ? "Disable Login" : "Enable Login") : "Enable/Disable Login";
        }

        private void CmbOffices_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (!IsLoaded)
            {
                return;
            }

            LoadUsers();
        }

        private void DgUsers_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            UpdateSelectedUserUi();
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new AddUserWindow { Owner = this };
            if (dialog.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void ChangeRole_Click(object sender, RoutedEventArgs e)
        {
            var user = GetSelectedUser();
            if (user == null)
            {
                return;
            }

            var dialog = new ChangeRoleWindow(user) { Owner = this };
            if (dialog.ShowDialog() == true)
            {
                LoadUsers();
            }
        }

        private void ToggleActive_Click(object sender, RoutedEventArgs e)
        {
            var user = GetSelectedUser();
            if (user == null)
            {
                return;
            }

            try
            {
                _userService.ToggleUserActive(user.Id, !user.Active);
                LoadUsers();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Users", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ManageSchedules_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ManageFlightSchedulesWindow { Owner = this };
            dialog.ShowDialog();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _authService.CloseSession(SessionContext.CurrentSessionId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Logout", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            SessionContext.Clear();
            var login = new LoginWindow();
            Application.Current.MainWindow = login;
            login.Show();
            Close();
        }
    }
}
