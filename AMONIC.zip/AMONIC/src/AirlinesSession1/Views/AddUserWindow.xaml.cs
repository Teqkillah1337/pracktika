using System;
using System.Text.RegularExpressions;
using System.Windows;
using AirlinesSession1.Models;
using AirlinesSession1.Services;

namespace AirlinesSession1.Views
{
    public partial class AddUserWindow : Window
    {
        private readonly UserService _userService = new UserService();

        public AddUserWindow()
        {
            InitializeComponent();
            Loaded += AddUserWindow_Loaded;
        }

        private void AddUserWindow_Loaded(object sender, RoutedEventArgs e)
        {
            cmbOffice.ItemsSource = _userService.GetOffices(false);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Validate();
                var selectedOffice = cmbOffice.SelectedItem as OfficeItem;
                var request = new AddUserRequest
                {
                    Email = txtEmail.Text.Trim(),
                    FirstName = txtFirstName.Text.Trim(),
                    LastName = txtLastName.Text.Trim(),
                    OfficeId = selectedOffice.Id.GetValueOrDefault(),
                    Birthdate = dpBirthdate.SelectedDate.Value.Date,
                    Password = txtPassword.Password.Trim()
                };

                _userService.AddUser(request);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Add user", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Validate()
        {
            if (string.IsNullOrWhiteSpace(txtEmail.Text) || !Regex.IsMatch(txtEmail.Text.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                throw new InvalidOperationException("Введите корректный e-mail.");
            }

            if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                throw new InvalidOperationException("Имя и фамилия обязательны.");
            }

            if (cmbOffice.SelectedItem == null)
            {
                throw new InvalidOperationException("Выберите офис.");
            }

            if (!dpBirthdate.SelectedDate.HasValue || dpBirthdate.SelectedDate.Value.Date >= DateTime.Today)
            {
                throw new InvalidOperationException("Введите корректную дату рождения.");
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Password))
            {
                throw new InvalidOperationException("Пароль обязателен.");
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
