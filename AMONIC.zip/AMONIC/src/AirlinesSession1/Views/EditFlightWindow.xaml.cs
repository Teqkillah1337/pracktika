using System;
using System.Globalization;
using System.Windows;
using AirlinesSession1.Models;
using AirlinesSession1.Services;

namespace AirlinesSession1.Views
{
    public partial class EditFlightWindow : Window
    {
        private readonly ScheduleItem _schedule;
        private readonly ScheduleService _scheduleService = new ScheduleService();

        public EditFlightWindow(ScheduleItem schedule)
        {
            InitializeComponent();
            _schedule = schedule ?? throw new ArgumentNullException("schedule");
            txtFrom.Text = "From: " + _schedule.DepartureAirportCode;
            txtTo.Text = "To: " + _schedule.ArrivalAirportCode;
            txtAircraft.Text = "Aircraft: " + _schedule.AircraftName;
            dpDate.SelectedDate = _schedule.DepartureDate;
            txtTime.Text = _schedule.DepartureTimeText;
            txtEconomyPrice.Text = _schedule.EconomyPrice.ToString("F2", CultureInfo.InvariantCulture);
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!dpDate.SelectedDate.HasValue)
                {
                    throw new InvalidOperationException("Выберите дату.");
                }

                TimeSpan time;
                if (!TimeSpan.TryParseExact(txtTime.Text.Trim(), new[] { @"hh\:mm", @"h\:mm", @"hh\:mm\:ss" }, CultureInfo.InvariantCulture, out time))
                {
                    throw new InvalidOperationException("Введите время в формате HH:mm.");
                }

                decimal price;
                if (!decimal.TryParse(txtEconomyPrice.Text.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out price) || price <= 0)
                {
                    throw new InvalidOperationException("Введите корректную цену эконом-класса.");
                }

                _scheduleService.UpdateSchedule(_schedule.Id, dpDate.SelectedDate.Value.Date, time, price);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Schedule edit", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
