using System;
using System.Windows;
using System.Windows.Threading;
using AirlinesSession1.Infrastructure;
using AirlinesSession1.Services;

namespace AirlinesSession1.Views
{
    public partial class LoginWindow : Window
    {
        private readonly AuthService _authService = new AuthService();
        private readonly DispatcherTimer _lockoutTimer;
        private int _failedAttempts;
        private DateTime? _lockoutUntil;

        public LoginWindow()
        {
            InitializeComponent();
            _lockoutTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _lockoutTimer.Tick += LockoutTimer_Tick;
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (IsLocked())
            {
                UpdateLockoutUi();
                return;
            }

            txtStatus.Text = string.Empty;
            txtCountdown.Text = string.Empty;

            try
            {
                var auth = _authService.Authenticate(txtEmail.Text, txtPassword.Password);
                if (!auth.Success)
                {
                    txtStatus.Text = auth.Message;
                    if (!auth.IsBlocked)
                    {
                        RegisterFailedAttempt();
                    }

                    return;
                }

                ResetLockout();

                var pendingCrash = _authService.GetPendingCrashSession(auth.User.Id);
                if (pendingCrash != null)
                {
                    var dialog = new CrashReasonWindow(pendingCrash) { Owner = this };
                    var dialogResult = dialog.ShowDialog();
                    if (dialogResult != true)
                    {
                        return;
                    }

                    _authService.MarkSessionCrash(pendingCrash.SessionId, dialog.SelectedCrashType, dialog.CrashReason);
                }

                var sessionId = _authService.StartSession(auth.User.Id);
                SessionContext.CurrentUser = auth.User;
                SessionContext.CurrentSessionId = sessionId;

                Window nextWindow = auth.User.IsAdmin ? (Window)new AdminWindow() : new UserWindow();
                Application.Current.MainWindow = nextWindow;
                nextWindow.Show();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Login", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void RegisterFailedAttempt()
        {
            _failedAttempts++;
            if (_failedAttempts < 3)
            {
                return;
            }

            _lockoutUntil = DateTime.Now.AddSeconds(10);
            _lockoutTimer.Start();
            UpdateLockoutUi();
        }

        private void ResetLockout()
        {
            _failedAttempts = 0;
            _lockoutUntil = null;
            _lockoutTimer.Stop();
            btnLogin.IsEnabled = true;
            txtCountdown.Text = string.Empty;
        }

        private bool IsLocked()
        {
            return _lockoutUntil.HasValue && _lockoutUntil.Value > DateTime.Now;
        }

        private void LockoutTimer_Tick(object sender, EventArgs e)
        {
            UpdateLockoutUi();
        }

        private void UpdateLockoutUi()
        {
            if (!IsLocked())
            {
                ResetLockout();
                return;
            }

            btnLogin.IsEnabled = false;
            var remaining = (_lockoutUntil.Value - DateTime.Now).TotalSeconds;
            if (remaining < 0)
            {
                remaining = 0;
            }

            txtCountdown.Text = string.Format("Слишком много неудачных попыток. Повторите вход через {0:0} сек.", Math.Ceiling(remaining));
        }
    }
}
