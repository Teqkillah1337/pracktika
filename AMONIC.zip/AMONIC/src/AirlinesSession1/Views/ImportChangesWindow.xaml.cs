using System;
using System.IO;
using System.Windows;
using AirlinesSession1.Services;
using Microsoft.Win32;

namespace AirlinesSession1.Views
{
    public partial class ImportChangesWindow : Window
    {
        private readonly ScheduleService _scheduleService = new ScheduleService();

        public ImportChangesWindow()
        {
            InitializeComponent();
            txtFilePath.Text = FindDefaultImportFile();
        }


        private static string FindDefaultImportFile()
        {
            var candidates = new[]
            {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Samples", "Schedules_V12.csv"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Schedules_V12.csv")
            };

            foreach (var candidate in candidates)
            {
                if (File.Exists(candidate))
                {
                    return candidate;
                }
            }

            return candidates[0];
        }

        private static string GetDefaultSamplesDirectory()
        {
            var candidates = new[]
            {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Samples"),
                AppDomain.CurrentDomain.BaseDirectory
            };

            foreach (var candidate in candidates)
            {
                if (Directory.Exists(candidate))
                {
                    return candidate;
                }
            }

            return AppDomain.CurrentDomain.BaseDirectory;
        }

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "CSV or text files|*.csv;*.txt|All files|*.*",
                InitialDirectory = GetDefaultSamplesDirectory()
            };

            if (dialog.ShowDialog(this) == true)
            {
                txtFilePath.Text = dialog.FileName;
            }
        }

        private void Import_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = _scheduleService.ImportChanges(txtFilePath.Text);
                txtSuccess.Text = result.SuccessfulChangesApplied.ToString();
                txtDuplicates.Text = result.DuplicateRecordsDiscarded.ToString();
                txtMissing.Text = result.RecordsWithMissingFieldsDiscarded.ToString();
                MessageBox.Show(this, "Импорт завершён.", "Import", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Import", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
