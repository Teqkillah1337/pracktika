using System;
using System.Windows;
using AirlinesSession1.Models;
using AirlinesSession1.Services;

namespace AirlinesSession1.Views
{
    public partial class ChangeRoleWindow : Window
    {
        private readonly UserService _userService = new UserService();
        private readonly AdminUserItem _user;

        public ChangeRoleWindow(AdminUserItem user)
        {
            InitializeComponent();
            _user = user ?? throw new ArgumentNullException("user");
            txtEmail.Text = _user.Email;
            txtFirstName.Text = _user.FirstName;
            txtLastName.Text = _user.LastName;
            txtOffice.Text = _user.OfficeTitle;
            rbAdministrator.IsChecked = _user.RoleId == 1;
            rbUser.IsChecked = _user.RoleId != 1;
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var roleId = rbAdministrator.IsChecked == true ? 1 : 2;
                _userService.ChangeUserRole(_user.Id, roleId);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Edit Role", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
