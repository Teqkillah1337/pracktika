namespace GibddInspectorApp.Models;

public class LocationInfo
{
    public string Street { get; set; } = string.Empty;
    public string House { get; set; } = string.Empty;
    public string RoadRow { get; set; } = string.Empty;
    public string Lane { get; set; } = string.Empty;

    public override string ToString() => $"{Street}, дом {House}, ряд {RoadRow}, полоса {Lane}";
}
