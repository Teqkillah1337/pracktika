namespace GibddInspectorApp.Models;

public enum AccidentClassification
{
    Столкновение,
    НаездНаПешехода,
    НаездНаПрепятствие,
    Опрокидывание,
    НаездНаЖивотное,
    Иное
}
