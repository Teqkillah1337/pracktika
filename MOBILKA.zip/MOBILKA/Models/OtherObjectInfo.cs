namespace GibddInspectorApp.Models;

public class OtherObjectInfo
{
    public string Name { get; set; } = string.Empty;
    public List<string> DamagePhotoPaths { get; set; } = new();

    public override string ToString() => Name;
}
