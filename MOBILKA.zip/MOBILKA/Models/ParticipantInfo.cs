namespace GibddInspectorApp.Models;

public class ParticipantInfo
{
    public string FullName { get; set; } = string.Empty;
    public string DriverLicenseNumber { get; set; } = string.Empty;
}
