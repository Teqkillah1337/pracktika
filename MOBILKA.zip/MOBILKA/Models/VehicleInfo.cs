namespace GibddInspectorApp.Models;

public class VehicleInfo
{
    public string PlateNumber { get; set; } = string.Empty;
    public string RegistrationCertificateNumber { get; set; } = string.Empty;
    public List<string> DamagePhotoPaths { get; set; } = new();

    public override string ToString() => $"{PlateNumber} / СТС {RegistrationCertificateNumber}";
}
