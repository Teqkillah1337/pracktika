namespace GibddInspectorApp.Models;

public class AccidentRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public AccidentClassification Classification { get; set; } = AccidentClassification.Столкновение;
    public DateOnly AccidentDate { get; set; } = DateOnly.FromDateTime(DateTime.Now);
    public TimeOnly AccidentTime { get; set; } = TimeOnly.FromDateTime(DateTime.Now);
    public LocationInfo Location { get; set; } = new();
    public List<ParticipantInfo> Participants { get; set; } = new();
    public List<VehicleInfo> Vehicles { get; set; } = new();
    public List<OtherObjectInfo> OtherObjects { get; set; } = new();
    public int VictimCount { get; set; }
    public string Comment { get; set; } = string.Empty;
    public List<string> GeneralPhotoPaths { get; set; } = new();
    public string SchemeImagePath { get; set; } = string.Empty;

    public string SummaryLocation => string.IsNullOrWhiteSpace(Location?.Street) ? "Место не указано" : Location.ToString();
    public int ParticipantsCount => Participants?.Count ?? 0;
    public string DateTimeText => $"{AccidentDate:dd.MM.yyyy} {AccidentTime.ToString(@"HH\:mm")}";
}
