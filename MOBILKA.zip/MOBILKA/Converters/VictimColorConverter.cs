using System.Globalization;

namespace GibddInspectorApp.Converters;

public class VictimColorConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var count = value is int v ? v : 0;
        return count switch
        {
            <= 0 => Colors.Green,
            1 => Colors.Orange,
            _ => Colors.Red
        };
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
