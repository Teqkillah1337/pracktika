using System.Globalization;

namespace GibddInspectorApp.Converters;

public class VictimTextConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var count = value is int v ? v : 0;
        return count == 0 ? "Без жертв" : $"Жертвы: {count}";
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => throw new NotImplementedException();
}
