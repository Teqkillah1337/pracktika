using ObjCRuntime;
using UIKit;

namespace GibddInspectorApp;

public class Program : UIApplicationDelegate
{
    static void Main(string[] args)
    {
        UIApplication.Main(args, null, typeof(AppDelegate));
    }
}
