using GibddInspectorApp.Converters;
using GibddInspectorApp.Pages;
using GibddInspectorApp.Services;
using Microsoft.Extensions.Logging;

namespace GibddInspectorApp;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

        builder.Services.AddSingleton<AccidentStorageService>();
        builder.Services.AddSingleton<AppShell>();
        builder.Services.AddSingleton<AccidentsListPage>();
        builder.Services.AddTransient<AccidentWizardPage>();
        builder.Services.AddTransient<AccidentDetailsPage>();

        builder.Services.AddSingleton<VictimColorConverter>();
        builder.Services.AddSingleton<VictimTextConverter>();
        builder.Services.AddSingleton<InverseBoolConverter>();




        return builder.Build();
    }
}
