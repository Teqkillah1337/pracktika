using System.Text.Json;
using GibddInspectorApp.Models;

namespace GibddInspectorApp.Services;

public class AccidentStorageService
{
    private readonly string _filePath;
    private readonly JsonSerializerOptions _jsonOptions = new() { WriteIndented = true };

    public AccidentStorageService()
    {
        _filePath = Path.Combine(FileSystem.AppDataDirectory, "accidents.json");
    }

    public async Task<List<AccidentRecord>> GetAllAsync()
    {
        if (!File.Exists(_filePath))
            return new List<AccidentRecord>();

        await using var stream = File.OpenRead(_filePath);
        var items = await JsonSerializer.DeserializeAsync<List<AccidentRecord>>(stream, _jsonOptions);
        return items ?? new List<AccidentRecord>();
    }

    public async Task<AccidentRecord?> GetByIdAsync(Guid id)
    {
        var items = await GetAllAsync();
        return items.FirstOrDefault(x => x.Id == id);
    }

    public async Task SaveAsync(AccidentRecord record)
    {
        var items = await GetAllAsync();
        var existing = items.FindIndex(x => x.Id == record.Id);

        if (existing >= 0)
            items[existing] = record;
        else
            items.Insert(0, record);

        Directory.CreateDirectory(FileSystem.AppDataDirectory);
        await using var stream = File.Create(_filePath);
        await JsonSerializer.SerializeAsync(stream, items, _jsonOptions);
    }

    public async Task<string> CopyToAppDataAsync(FileResult fileResult)
    {
        var extension = Path.GetExtension(fileResult.FileName);
        var target = Path.Combine(FileSystem.AppDataDirectory, $"{Guid.NewGuid()}{extension}");

        await using var source = await fileResult.OpenReadAsync();
        await using var destination = File.Create(target);
        await source.CopyToAsync(destination);
        return target;
    }

    public async Task<string> SaveBytesAsync(byte[] bytes, string extension)
    {
        var target = Path.Combine(FileSystem.AppDataDirectory, $"{Guid.NewGuid()}{extension}");
        await File.WriteAllBytesAsync(target, bytes);
        return target;
    }
}
