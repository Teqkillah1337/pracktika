using GibddInspectorApp.Models;
using GibddInspectorApp.Services;

namespace GibddInspectorApp.Pages;

public partial class AccidentDetailsPage : ContentPage, IQueryAttributable
{
    private readonly AccidentStorageService _storageService;
    private Guid _id;

    public AccidentDetailsPage(AccidentStorageService storageService)
    {
        InitializeComponent();
        _storageService = storageService;
    }

    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        if (query.TryGetValue("id", out var value) && Guid.TryParse(value?.ToString(), out var id))
            _id = id;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_id != Guid.Empty)
            await LoadAsync();
    }

    private async Task LoadAsync()
    {
        var accident = await _storageService.GetByIdAsync(_id);
        if (accident is null)
        {
            await DisplayAlert("Ошибка", "Запись не найдена", "OK");
            await Shell.Current.GoToAsync("..");
            return;
        }

        HeaderLabel.Text = accident.Classification.ToString();
        DateLabel.Text = $"Дата и время: {accident.DateTimeText}";
        VictimsLabel.Text = accident.VictimCount == 0 ? "Жертв нет" : $"Количество жертв: {accident.VictimCount}";
        LocationLabel.Text = $"Место: {accident.SummaryLocation}";
        CommentLabel.Text = $"Комментарий: {accident.Comment}";

        ParticipantsContainer.Children.Clear();
        foreach (var person in accident.Participants)
            ParticipantsContainer.Children.Add(CreateTextCard($"{person.FullName}\nВУ: {person.DriverLicenseNumber}"));

        VehiclesContainer.Children.Clear();
        foreach (var vehicle in accident.Vehicles)
            VehiclesContainer.Children.Add(CreateRichCard(vehicle.ToString(), vehicle.DamagePhotoPaths));

        ObjectsContainer.Children.Clear();
        foreach (var item in accident.OtherObjects)
            ObjectsContainer.Children.Add(CreateRichCard(item.Name, item.DamagePhotoPaths));

        GeneralPhotosView.ItemsSource = accident.GeneralPhotoPaths;
        SchemeImage.Source = string.IsNullOrWhiteSpace(accident.SchemeImagePath) ? null : ImageSource.FromFile(accident.SchemeImagePath);
    }

    private View CreateTextCard(string text)
    {
        return new Frame
        {
            Padding = 10,
            CornerRadius = 12,
            BackgroundColor = Color.FromArgb("#F9FAFB"),
            Content = new Label { Text = text }
        };
    }

    private View CreateRichCard(string title, IEnumerable<string> photos)
    {
        var stack = new VerticalStackLayout { Spacing = 8 };
        stack.Children.Add(new Label { Text = title, FontAttributes = FontAttributes.Bold });

        var list = photos?.ToList() ?? new List<string>();
        if (list.Any())
        {
            var photoView = new CollectionView
            {
                HeightRequest = 120,
                ItemsSource = list,
                SelectionMode = SelectionMode.None,
                ItemsLayout = new LinearItemsLayout(ItemsLayoutOrientation.Horizontal) { ItemSpacing = 8 },
                ItemTemplate = new DataTemplate(() =>
                {
                    var image = new Image { HeightRequest = 90, WidthRequest = 90, Aspect = Aspect.AspectFill };
                    image.SetBinding(Image.SourceProperty, ".");
                    return new Frame { Padding = 4, CornerRadius = 10, Content = image, BackgroundColor = Color.FromArgb("#F3F4F6") };
                })
            };
            stack.Children.Add(photoView);
        }
        else
        {
            stack.Children.Add(new Label { Text = "Фото повреждений не приложены" });
        }

        return new Frame
        {
            Padding = 10,
            CornerRadius = 12,
            BackgroundColor = Color.FromArgb("#F9FAFB"),
            Content = stack
        };
    }
}
