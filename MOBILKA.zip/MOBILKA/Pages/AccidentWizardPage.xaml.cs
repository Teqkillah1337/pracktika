using System.Collections.ObjectModel;
using GibddInspectorApp.Models;
using GibddInspectorApp.Services;
using Microsoft.Maui.Graphics;

namespace GibddInspectorApp.Pages;

public partial class AccidentWizardPage : ContentPage
{
    private readonly AccidentStorageService _storageService;
    private readonly ObservableCollection<string> _generalPhotos = new();
    private readonly List<ParticipantEditorModel> _participants = new();
    private readonly List<VehicleEditorModel> _vehicles = new();
    private readonly List<ObjectEditorModel> _objects = new();
    private readonly SchemeDrawable _schemeDrawable = new();
    private int _currentStep = 1;

    public AccidentWizardPage(AccidentStorageService storageService)
    {
        InitializeComponent();
        _storageService = storageService;
        ClassificationPicker.ItemsSource = Enum.GetNames(typeof(AccidentClassification)).ToList();
        ClassificationPicker.SelectedIndex = 0;
        GeneralPhotosView.ItemsSource = _generalPhotos;
        SchemeCanvas.Drawable = _schemeDrawable;

        AddParticipantCard();
        AddVehicleCard();
        UpdateStepState();
    }

    private void AddParticipantCard(string? fullName = null, string? license = null)
    {
        var model = new ParticipantEditorModel
        {
            FullNameEntry = new Entry { Placeholder = "ФИО" , Text = fullName ?? string.Empty},
            LicenseEntry = new Entry { Placeholder = "Номер водительского удостоверения", Text = license ?? string.Empty }
        };

        var removeButton = new Button { Text = "Удалить", BackgroundColor = Color.FromArgb("#FEE2E2"), TextColor = Color.FromArgb("#991B1B"), CornerRadius = 12 };
        var frame = new Frame
        {
            CornerRadius = 16,
            Padding = 12,
            BackgroundColor = Color.FromArgb("#F8FAFC"),
            Content = new VerticalStackLayout
            {
                Spacing = 8,
                Children =
                {
                    new Label { Text = $"Участник {_participants.Count + 1}", FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#0F172A") },
                    model.FullNameEntry,
                    model.LicenseEntry,
                    removeButton
                }
            }
        };

        model.Container = frame;
        removeButton.Clicked += (_, _) =>
        {
            if (_participants.Count <= 1)
                return;
            _participants.Remove(model);
            ParticipantsLayout.Children.Remove(frame);
            RefreshParticipantTitles();
        };

        _participants.Add(model);
        ParticipantsLayout.Children.Add(frame);
        RefreshParticipantTitles();
    }

    private void RefreshParticipantTitles()
    {
        for (var i = 0; i < _participants.Count; i++)
        {
            if (_participants[i].Container?.Content is VerticalStackLayout stack && stack.Children[0] is Label label)
                label.Text = $"Участник {i + 1}";
        }
    }

    private void AddVehicleCard(string? plate = null, string? certificate = null)
    {
        var model = new VehicleEditorModel
        {
            PlateEntry = new Entry { Placeholder = "Госномер", Text = plate ?? string.Empty },
            CertificateEntry = new Entry { Placeholder = "Номер свидетельства о регистрации", Text = certificate ?? string.Empty },
            Photos = new ObservableCollection<string>()
        };

        var photoButton = new Button { Text = "Добавить фото повреждений", BackgroundColor = Color.FromArgb("#E8F0FF"), TextColor = Color.FromArgb("#1E3A8A"), CornerRadius = 12 };
        var removeButton = new Button { Text = "Удалить", BackgroundColor = Color.FromArgb("#FEE2E2"), TextColor = Color.FromArgb("#991B1B"), CornerRadius = 12 };
        var photosView = new CollectionView
        {
            HeightRequest = 120,
            ItemsSource = model.Photos,
            SelectionMode = SelectionMode.None,
            ItemsLayout = new LinearItemsLayout(ItemsLayoutOrientation.Horizontal) { ItemSpacing = 8 },
            ItemTemplate = new DataTemplate(() =>
            {
                var image = new Image { HeightRequest = 90, WidthRequest = 90, Aspect = Aspect.AspectFill };
                image.SetBinding(Image.SourceProperty, ".");
                return new Frame { Padding = 4, CornerRadius = 10, Content = image, BackgroundColor = Color.FromArgb("#F3F4F6") };
            })
        };

        photoButton.Clicked += async (_, _) =>
        {
            var path = await PickOrCapturePhotoAsync();
            if (!string.IsNullOrWhiteSpace(path))
                model.Photos.Add(path);
        };

        var frame = new Frame
        {
            CornerRadius = 16,
            Padding = 12,
            BackgroundColor = Color.FromArgb("#F8FAFC"),
            Content = new VerticalStackLayout
            {
                Spacing = 8,
                Children =
                {
                    new Label { Text = $"Транспортное средство {_vehicles.Count + 1}", FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#0F172A") },
                    model.PlateEntry,
                    model.CertificateEntry,
                    photoButton,
                    photosView,
                    removeButton
                }
            }
        };

        model.Container = frame;
        removeButton.Clicked += (_, _) =>
        {
            _vehicles.Remove(model);
            VehiclesLayout.Children.Remove(frame);
            RefreshVehicleTitles();
        };

        _vehicles.Add(model);
        VehiclesLayout.Children.Add(frame);
        RefreshVehicleTitles();
    }

    private void RefreshVehicleTitles()
    {
        for (var i = 0; i < _vehicles.Count; i++)
        {
            if (_vehicles[i].Container?.Content is VerticalStackLayout stack && stack.Children[0] is Label label)
                label.Text = $"Транспортное средство {i + 1}";
        }
    }

    private void AddObjectCard(string? name = null)
    {
        var model = new ObjectEditorModel
        {
            NameEntry = new Entry { Placeholder = "Препятствие, животное и т.д.", Text = name ?? string.Empty },
            Photos = new ObservableCollection<string>()
        };

        var photoButton = new Button { Text = "Добавить фото повреждений", BackgroundColor = Color.FromArgb("#E8F0FF"), TextColor = Color.FromArgb("#1E3A8A"), CornerRadius = 12 };
        var removeButton = new Button { Text = "Удалить", BackgroundColor = Color.FromArgb("#FEE2E2"), TextColor = Color.FromArgb("#991B1B"), CornerRadius = 12 };
        var photosView = new CollectionView
        {
            HeightRequest = 120,
            ItemsSource = model.Photos,
            SelectionMode = SelectionMode.None,
            ItemsLayout = new LinearItemsLayout(ItemsLayoutOrientation.Horizontal) { ItemSpacing = 8 },
            ItemTemplate = new DataTemplate(() =>
            {
                var image = new Image { HeightRequest = 90, WidthRequest = 90, Aspect = Aspect.AspectFill };
                image.SetBinding(Image.SourceProperty, ".");
                return new Frame { Padding = 4, CornerRadius = 10, Content = image, BackgroundColor = Color.FromArgb("#F3F4F6") };
            })
        };

        photoButton.Clicked += async (_, _) =>
        {
            var path = await PickOrCapturePhotoAsync();
            if (!string.IsNullOrWhiteSpace(path))
                model.Photos.Add(path);
        };

        var frame = new Frame
        {
            CornerRadius = 16,
            Padding = 12,
            BackgroundColor = Color.FromArgb("#F8FAFC"),
            Content = new VerticalStackLayout
            {
                Spacing = 8,
                Children =
                {
                    new Label { Text = $"Объект {_objects.Count + 1}", FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#0F172A") },
                    model.NameEntry,
                    photoButton,
                    photosView,
                    removeButton
                }
            }
        };

        model.Container = frame;
        removeButton.Clicked += (_, _) =>
        {
            _objects.Remove(model);
            ObjectsLayout.Children.Remove(frame);
            RefreshObjectTitles();
        };

        _objects.Add(model);
        ObjectsLayout.Children.Add(frame);
        RefreshObjectTitles();
    }

    private void RefreshObjectTitles()
    {
        for (var i = 0; i < _objects.Count; i++)
        {
            if (_objects[i].Container?.Content is VerticalStackLayout stack && stack.Children[0] is Label label)
                label.Text = $"Объект {i + 1}";
        }
    }

    private void OnAddParticipantClicked(object sender, EventArgs e) => AddParticipantCard();
    private void OnAddVehicleClicked(object sender, EventArgs e) => AddVehicleCard();
    private void OnAddObjectClicked(object sender, EventArgs e) => AddObjectCard();

    private async void OnAddGeneralPhotoClicked(object sender, EventArgs e)
    {
        var path = await PickOrCapturePhotoAsync();
        if (!string.IsNullOrWhiteSpace(path))
            _generalPhotos.Add(path);
    }

    private async Task<string?> PickOrCapturePhotoAsync()
    {
        try
        {
            FileResult? file;
            if (MediaPicker.Default.IsCaptureSupported)
                file = await MediaPicker.Default.CapturePhotoAsync();
            else
                file = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Выберите фотографию" });

            return file is null ? null : await _storageService.CopyToAppDataAsync(file);
        }
        catch
        {
            return null;
        }
    }

    private void UpdateStepState()
    {
        Step1Panel.IsVisible = _currentStep == 1;
        Step2Panel.IsVisible = _currentStep == 2;
        Step3Panel.IsVisible = _currentStep == 3;
        Step4Panel.IsVisible = _currentStep == 4;
        Step5Panel.IsVisible = _currentStep == 5;
        PreviousButton.IsEnabled = _currentStep > 1;
        NextButton.IsVisible = _currentStep < 5;
        StepTitleLabel.Text = $"Шаг {_currentStep} из 5";
        SummaryLabel.Text = BuildSummary();
    }

    private string BuildSummary()
    {
        return $"Классификация: {ClassificationPicker.SelectedItem}\n" +
               $"Дата: {AccidentDatePicker.Date:dd.MM.yyyy} {AccidentTimePicker.Time:hh\\:mm}\n" +
               $"Участников: {_participants.Count}\n" +
               $"Машин: {_vehicles.Count}\n" +
               $"Объектов: {_objects.Count}\n" +
               $"Фото: {_generalPhotos.Count}";
    }

    private void OnPreviousClicked(object sender, EventArgs e)
    {
        if (_currentStep > 1)
        {
            _currentStep--;
            UpdateStepState();
        }
    }

    private void OnNextClicked(object sender, EventArgs e)
    {
        if (_currentStep < 5)
        {
            _currentStep++;
            UpdateStepState();
        }
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        var filledParticipants = _participants
            .Select(x => new ParticipantInfo
            {
                FullName = x.FullNameEntry.Text?.Trim() ?? string.Empty,
                DriverLicenseNumber = x.LicenseEntry.Text?.Trim() ?? string.Empty
            })
            .Where(x => !string.IsNullOrWhiteSpace(x.FullName) || !string.IsNullOrWhiteSpace(x.DriverLicenseNumber))
            .ToList();

        if (!filledParticipants.Any() || filledParticipants.Any(x => string.IsNullOrWhiteSpace(x.FullName) || string.IsNullOrWhiteSpace(x.DriverLicenseNumber)))
        {
            await DisplayAlert("Ошибка", "Нужен минимум один участник с заполненными ФИО и номером водительского удостоверения.", "OK");
            _currentStep = 2;
            UpdateStepState();
            return;
        }

        var accident = new AccidentRecord
        {
            Classification = Enum.TryParse<AccidentClassification>(ClassificationPicker.SelectedItem?.ToString(), out var classification)
                ? classification
                : AccidentClassification.Столкновение,
            AccidentDate = DateOnly.FromDateTime(AccidentDatePicker.Date),
            AccidentTime = new TimeOnly(AccidentTimePicker.Time.Hours, AccidentTimePicker.Time.Minutes),
            VictimCount = int.TryParse(VictimCountEntry.Text, out var victims) ? victims : 0,
            Comment = CommentEditor.Text?.Trim() ?? string.Empty,
            Location = new LocationInfo
            {
                Street = StreetEntry.Text?.Trim() ?? string.Empty,
                House = HouseEntry.Text?.Trim() ?? string.Empty,
                RoadRow = RoadRowEntry.Text?.Trim() ?? string.Empty,
                Lane = LaneEntry.Text?.Trim() ?? string.Empty
            },
            Participants = filledParticipants,
            Vehicles = _vehicles.Select(x => new VehicleInfo
            {
                PlateNumber = x.PlateEntry.Text?.Trim() ?? string.Empty,
                RegistrationCertificateNumber = x.CertificateEntry.Text?.Trim() ?? string.Empty,
                DamagePhotoPaths = x.Photos.ToList()
            }).Where(x => !string.IsNullOrWhiteSpace(x.PlateNumber) || !string.IsNullOrWhiteSpace(x.RegistrationCertificateNumber) || x.DamagePhotoPaths.Any()).ToList(),
            OtherObjects = _objects.Select(x => new OtherObjectInfo
            {
                Name = x.NameEntry.Text?.Trim() ?? string.Empty,
                DamagePhotoPaths = x.Photos.ToList()
            }).Where(x => !string.IsNullOrWhiteSpace(x.Name) || x.DamagePhotoPaths.Any()).ToList(),
            GeneralPhotoPaths = _generalPhotos.ToList()
        };

        var capture = await SchemeCanvas.CaptureAsync();
        if (capture != null)
        {
            await using var stream = await capture.OpenReadAsync();
            using var memory = new MemoryStream();
            await stream.CopyToAsync(memory);
            accident.SchemeImagePath = await _storageService.SaveBytesAsync(memory.ToArray(), ".png");
        }

        await _storageService.SaveAsync(accident);
        await DisplayAlert("Готово", "ДТП сохранено", "OK");
        await Shell.Current.GoToAsync("..");
    }

    private void OnClearSchemeClicked(object sender, EventArgs e)
    {
        _schemeDrawable.Clear();
        SchemeCanvas.Invalidate();
    }

    private void OnCanvasStart(object sender, TouchEventArgs e)
    {
        _schemeDrawable.StartLine(e.Touches.FirstOrDefault());
        SchemeCanvas.Invalidate();
    }

    private void OnCanvasDrag(object sender, TouchEventArgs e)
    {
        _schemeDrawable.AddPoint(e.Touches.FirstOrDefault());
        SchemeCanvas.Invalidate();
    }

    private void OnCanvasEnd(object sender, TouchEventArgs e)
    {
        _schemeDrawable.AddPoint(e.Touches.FirstOrDefault());
        SchemeCanvas.Invalidate();
    }

    private sealed class ParticipantEditorModel
    {
        public Entry FullNameEntry { get; set; } = default!;
        public Entry LicenseEntry { get; set; } = default!;
        public Frame? Container { get; set; }
    }

    private sealed class VehicleEditorModel
    {
        public Entry PlateEntry { get; set; } = default!;
        public Entry CertificateEntry { get; set; } = default!;
        public ObservableCollection<string> Photos { get; set; } = new();
        public Frame? Container { get; set; }
    }

    private sealed class ObjectEditorModel
    {
        public Entry NameEntry { get; set; } = default!;
        public ObservableCollection<string> Photos { get; set; } = new();
        public Frame? Container { get; set; }
    }

    private sealed class SchemeDrawable : IDrawable
    {
        private readonly List<List<PointF>> _lines = new();

        public void StartLine(PointF point)
        {
            _lines.Add(new List<PointF> { point });
        }

        public void AddPoint(PointF point)
        {
            if (!_lines.Any())
                _lines.Add(new List<PointF>());
            _lines.Last().Add(point);
        }

        public void Clear() => _lines.Clear();

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.StrokeColor = Colors.DarkBlue;
            canvas.StrokeSize = 3;

            foreach (var line in _lines)
            {
                for (var i = 1; i < line.Count; i++)
                    canvas.DrawLine(line[i - 1], line[i]);
            }
        }
    }
}
