using System.Collections.ObjectModel;
using GibddInspectorApp.Models;
using GibddInspectorApp.Services;

namespace GibddInspectorApp.Pages;

public partial class AccidentsListPage : ContentPage
{
    private readonly AccidentStorageService _storageService;
    public ObservableCollection<AccidentRecord> Accidents { get; } = new();

    public AccidentsListPage(AccidentStorageService storageService)
    {
        InitializeComponent();
        _storageService = storageService;
        BindingContext = this;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadAsync();
    }

    private async Task LoadAsync()
    {
        Accidents.Clear();
        var items = await _storageService.GetAllAsync();
        foreach (var item in items.OrderByDescending(x => x.AccidentDate).ThenByDescending(x => x.AccidentTime))
            Accidents.Add(item);
    }

    private async void OnAddClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(AccidentWizardPage));
    }

    private async void OnOpenClicked(object sender, EventArgs e)
    {
        if (sender is Button button && button.CommandParameter is Guid id)
            await Shell.Current.GoToAsync($"{nameof(AccidentDetailsPage)}?id={id}");
        else if (sender is Button button2 && Guid.TryParse(button2.CommandParameter?.ToString(), out var parsedId))
            await Shell.Current.GoToAsync($"{nameof(AccidentDetailsPage)}?id={parsedId}");
    }
}
