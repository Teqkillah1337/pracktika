using GibddInspectorApp.Pages;

namespace GibddInspectorApp;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute(nameof(AccidentWizardPage), typeof(AccidentWizardPage));
        Routing.RegisterRoute(nameof(AccidentDetailsPage), typeof(AccidentDetailsPage));
    }
}
